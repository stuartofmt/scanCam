#!/bin/sh
# Install the program (made by prep_and_package.py). Arguments go to install.py.
cd "$(dirname "$0")"
exec python3 install.py "$@"
